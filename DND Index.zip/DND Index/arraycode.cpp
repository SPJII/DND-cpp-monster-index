// arraycode.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>
using namespace std;

class Monster {
public:

	string Name;

	string power;
	string weakness;

	int level;

	int Speech;
	int Strenght;
	int speed;
	int health;


	int printMonster std::ostream& operator<<(std::ostream& os, const Monster& attribute) {
		return os << "("
			<< attribute.Name << endl
			<< attribute.level << endl
			<< attribute.health << endl
			<< " " << endl
			<< attribute.Strenght << endl
			<< attribute.Speed << endl
			<< attribute.Speech << endl
			<< " " << endl
			<< attribute.power << endl
			<< attribute.weakness << endl
			<< ")";
	};
};

int main() {
	Monster Demonlord = { "Demonlord","Hellfire","Holy energy",100,25,41,6,666 };

	//std:: cout << Demonlord.Name <<" "<<Demonlord.level<<" "<<Demonlord.health;
	std::cout << Demonlord << "\n";
};